<!DOCTYPE html>
<html>

<head>
    <title>Contoh Validasi Form Dengan PHP</title>
    <link rel="stylesheet" type="text/css" href="css.css">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>

<body>

    <br>
    <br>

    <form method="post" action="insert.php">
        <div class="container">
            <div class="input-output">
            <h2>FORMULIR PESERTA DIDIK</h2>
            <BR>image.png
                <div class="form-group row">
                    <label for="tanggal" class="col-sm-3 col-form-label">Tanggal</label>
                    <div class="col-sm-9">
                        <input type="date" class="form-control" name="tanggal" id="tanggal">
                        <br>
                    </div>
                </div>
            </div>
        </div>
    <br>
    <br>

    <div class="container">
            <div class="input-output">
                <h2>Registrasi Perserta Didik</h2>
                <br>
                <div class="form-group row">
                    <label for="jenis_pendaftaran" class="col-sm-3 col-form-label">Jenis Pendaftaran</label>
                    <div class="col-sm-9">
                        <select class="form-control" name="jenis_pendaftaran" id="jenis_pendaftaran">
                            <option value="siswa_baru">Siswa Baru</option>
                            <option value="pindahan">Pindahan</option>
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="tanggal_masuk_sekolah" class="col-sm-3 col-form-label">Tanggal Masuk Sekolah</label>
                    <div class="col-sm-9">
                        <input type="date" class="form-control" name="tanggal_masuk_sekolah" id="tanggal_masuk_sekolah">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="nis" class="col-sm-3 col-form-label">NIS</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" name="nis" id="nis">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="nomor_peserta_ujian" class="col-sm-3 col-form-label">Nomor Peserta Ujian</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" name="nomor_peserta_ujian" id="nomor_peserta_ujian">
                    </div>
                </div>
                
                <div class="form-group row">
                    <label for="pernah_paud" class="col-sm-3 col-form-label">Apakah Pernah PAUD?</label>
                    <div class="col-sm-9">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="pernah_paud" id="pernah_paud1"
                                value="ya">
                            <label class="form-check-label" for="pernah_paud1">
                                Ya
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="pernah_paud" id="pernah_paud2"
                                value="tidak">
                            <label class="form-check-label" for="pernah_paud2">
                                Tidak
                            </label>
                        </div>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="pernah_tk" class="col-sm-3 col-form-label">Apakah Pernah TK?</label>
                    <div class="col-sm-9">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="pernah_tk" id="pernah_tk1" value="ya">
                            <label class="form-check-label" for="pernah_tk1">
                                Ya
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="pernah_tk" id="pernah_tk2" value="tidak">
                            <label class="form-check-label" for="pernah_tk2">
                                Tidak
                            </label>
                        </div>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="no_seri_skhun_sebelumnya" class="col-sm-3 col-form-label">No Seri SKHUN Sebelumnya</label>
                    <div class="col-sm-9">
                        <input type="text" name="no_seri_skhun_sebelumnya" class="form-control" id="no_seri_skhun_sebelumnya"
                            placeholder="No Seri SKHUN Sebelumnya">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="no_seri_ijasah_sebelumnya" class="col-sm-3 col-form-label">No Seri Ijasah Sebelumnya</label>
                    <div class="col-sm-9">
                        <input type="text" name="no_seri_ijasah_sebelumnya" class="form-control" id="no_seri_ijasah_sebelumnya"
                            placeholder="No Seri Ijasah Sebelumnya">
                    </div>
                </div>
                <div class="form-group">
                    <label for="hobi">Hobi</label>
                    <select class="form-control" id="hobi" name="hobi">
                        <option value="">Pilih Hobi</option>
                        <option value="olahraga">Olahraga</option>
                        <option value="kesenian">Kesenian</option>
                        <option value="membaca">Membaca</option>
                        <option value="menulis">Menulis</option>
                        <option value="traveling">Traveling</option>
                        <option value="lainnya">Lainnya</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="cita-cita">Cita-Cita:</label>
                    <select class="form-control" id="cita-cita" name="cita_cita">
                        <option value="">Pilih Cita-Cita</option>
                        <option value="PNS">PNS</option>
                        <option value="TNI/POLRI">TNI/POLRI</option>
                        <option value="Guru/Dosen">Guru/Dosen</option>
                        <option value="Dokter">Dokter</option>
                        <option value="Politikus">Politikus</option>
                        <option value="Wiraswasta">Wiraswasta</option>
                        <option value="Seni Lukis/Artis/Sejenisnya">Seni Lukis/Artis/Sejenisnya</option>
                        <option value="Lainnya">Lainnya</option>
                    </select>
                </div>
            </div>
        </div>

        <br>
        <br>

        <div class="container">
<div class="input-output">
<h2>Data Pribadi</h2>
    <br>
  <div class="form-group">
    <label for="nama_lengkap">Nama Lengkap</label>
    <input type="text" class="form-control" name="nama_lengkap" id="nama_lengkap" placeholder="Nama Lengkap">
  </div>
  <div class="form-group">
    <label for="jenis_kelamin">Jenis Kelamin</label>
    <select class="form-control" name="jenis_kelamin" id="jenis_kelamin">
      <option value="laki-laki">Laki-laki</option>
      <option value="perempuan">Perempuan</option>
    </select>
  </div>
  <div class="form-group">
    <label for="nisn">NISN</label>
    <input type="text" class="form-control" name="nisn" id="nisn" placeholder="NISN">
  </div>
  <div class="form-group">
    <label for="nik">NIK</label>
    <input type="text" class="form-control" name="nik" id="nik" placeholder="NIK">
  </div>
  <div class="form-group">
    <label for="tempat_lahir">Tempat Lahir</label>
    <input type="text" class="form-control" name="tempat_lahir" id="tempat_lahir" placeholder="Tempat Lahir">
  </div>
  
  <div class="form-group row">
  <label for="tanggal_lahir" class="col-sm-2 col-form-label">Tanggal Lahir</label>
  <div class="col-sm-10">
    <input type="date" name="tanggal_lahir" class="form-control" id="tanggal_lahir" placeholder="Tanggal Lahir">
  </div>
</div>

<div class="form-group row">
  <label for="agama" class="col-sm-2 col-form-label">Agama</label>
  <div class="col-sm-10">
    <select class="form-control" name="agama" id="agama">
      <option value="">- Pilih Agama -</option>
      <option value="Islam">Islam</option>
      <option value="Kristen/Protestan">Kristen/Protestan</option>
      <option value="Katholik">Katholik</option>
      <option value="Hindu">Hindu</option>
      <option value="Budha">Budha</option>
      <option value="Konghucu">Konghucu</option>
      <option value="Lainnya">Lainnya</option>
    </select>
  </div>
</div>

<div class="form-group row">
  <label for="berkebutuhan_khusus" class="col-sm-2 col-form-label">Berkebutuhan Khusus</label>
  <div class="col-sm-10">
    <select class="form-control" name="berkebutuhan_khusus" id="berkebutuhan_khusus">
    <option value="">- Pilih -</option>
      <option value="Tidak">Tidak</option>
      <option value="Netra">Netra</option>
      <option value="Rungu">Rungu</option>
      <option value="Grahita Ringan">Grahita Ringan</option>
      <option value="Grahita Sedang">Grahita Sedang</option>
      <option value="Daksa Ringan">Daksa Ringan</option>
      <option value="Laras">Laras</option>
      <option value="Indigo">Indigo</option>
    </select>
  </div>
</div>

<div class="form-group">
    <label for="alamat_jalan">Alamat Jalan</label>
    <input type="text" name="alamat_jalan" class="form-control" id="alamat_jalan" placeholder="Alamat Jalan">
</div>
<div class="form-group row">
    <div class="col-md-6">
        <label for="rt">RT</label>
        <input type="text" name="rt" class="form-control" id="rt" placeholder="RT">
    </div>
    <div class="col-md-6">
        <label for="rw">RW</label>
        <input type="text" name="rw" class="form-control" id="rw" placeholder="RW">
    </div>
</div>
<div class="form-group">
    <label for="nama_dusun">Nama Dusun</label>
    <input type="text" name="nama_dusun" class="form-control" id="nama_dusun" placeholder="Nama Dusun">
</div>
<div class="form-group">
    <label for="nama_kelurahan_desa">Nama Kelurahan/Desa</label>
    <input type="text" name="nama_kelurahan_desa" class="form-control" id="nama_kelurahan_desa" placeholder="Nama Kelurahan/Desa">
</div>
<div class="form-group">
    <label for="kecamatan">Kecamatan</label>
    <input type="text" name="kecamatan" class="form-control" id="kecamatan" placeholder="Kecamatan">
</div>
<div class="form-group">
    <label for="kode_pos">Kode Pos</label>
    <input type="text" name="kode_pos" class="form-control" id="kode_pos" placeholder="Kode Pos">
</div>

<div class="form-group">
    <label for="tempat_tinggal">Tempat Tinggal</label>
    <select name="tempat_tinggal" class="form-control" id="tempat_tinggal">
        <option value="">- Pilih Tempat Tinggal -</option>
        <option value="Orang Tua">Bersama Orang Tua</option>
        <option value="Wali">Wali</option>
        <option value="Kos">Kos</option>
        <option value="Asrama">Asrama</option>
        <option value="Panti">Panti Asuhan</option>
        <option value="Lainnya">Lainnya</option>
    </select>
</div>

<div class="form-group row">
    <label for="moda_transportasi" class="col-sm-3 col-form-label">Moda Transportasi</label>
    <div class="col-sm-9">
        <select class="form-control" id="moda_transportasi" name="moda_transportasi">
        <option value="">- Pilih Transportasi -</option>
            <option value="sepeda">Sepeda</option>
            <option value="motor">Motor</option>
            <option value="mobil">Mobil</option>
            <option value="angkot">Angkutan Umum</option>
            <option value="kereta">Kereta Api</option>
            <option value="pesawat">Pesawat Terbang</option>
            <option value="lainnya">Lainnya</option>
        </select>
    </div>
</div>

<div class="form-group row">
    <label for="nomor_hp" class="col-sm-3 col-form-label">Nomor HP</label>
    <div class="col-sm-9">
        <input type="text" class="form-control" id="nomor_hp" name="nomor_hp">
    </div>
</div>

<div class="form-group row">
    <label for="nomor_telepon" class="col-sm-3 col-form-label">Nomor Telepon</label>
    <div class="col-sm-9">
        <input type="text" class="form-control" id="nomor_telepon" name="nomor_telepon">
    </div>
</div>

<div class="form-group row">
    <label for="email_pribadi" class="col-sm-3 col-form-label">E-Mail Pribadi</label>
    <div class="col-sm-9">
        <input type="email" class="form-control" id="email_pribadi" name="email_pribadi">
    </div>
</div>

<div class="form-group row">
    <label for="penerima_kps_pkh_kip" class="col-sm-3 col-form-label">Penerima KPS/KKS/PKH/KIP</label>
    <div class="col-sm-9">
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="penerima_kps_pkh_kip" id="penerima_kps_pkh_kip" value="ya">
            <label class="form-check-label" for="penerima_kps_pkh_kip">Ya</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="penerima_kip" id="penerima_kip_tidak" value="tidak">
            <label class="form-check-label" for="penerima_kip_tidak">Tidak</label>
        </div>
    </div>
</div>


<div class="form-group row">
    <label for="no_kps_pkh_kip" class="col-sm-3 col-form-label">No KPS/KKS/PKH/KIP</label>
    <div class="col-sm-9">
        <input type="text" class="form-control" placeholder="- Isi Jika Ada -" id="no_kps_pkh_kip" name="no_kps_pkh_kip" enabled>
    </div>
</div>

<div class="form-group row">
    <label for="kewarganegaraan" class="col-sm-3 col-form-label">Kewarganegaraan</label>
    <div class="col-sm-9">
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="kewarganegaraan" id="kewarganegaraan1" value="wni" checked>
            <label class="form-check-label" for="kewarganegaraan1">
                Indonesia (WNI)
            </label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="kewarganegaraan" id="kewarganegaraan2" value="wna">
            <label class="form-check-label" for="kewarganegaraan2">
                Asing (WNA)
            </label>
        </div>
        <div class="form-group mt-3">
            <label for="negara" class="col-sm-3 col-form-label">Negara</label>
            <div class="col-sm-9">
                <input type="text" class="form-control" id="negara" name="negara" placeholder="Masukkan nama negara (KHUSUS WNA)">
            </div>
        </div>
    </div>
</div>
<div class="container" style="text-align: right;">
<button type="submit" value="submit" class="btn btn-primary">Submit</button>
</div>
</div>

    </div>
    </form>

</body>

</html>