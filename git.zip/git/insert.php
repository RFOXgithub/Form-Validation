<?php
// Konfigurasi koneksi ke database
$host = "localhost";
$username = "root";
$password = "BAPAKKAO";
$dbname = "my_db";

// Buat koneksi PDO
$dsn = "mysql:host=$host;dbname=$dbname";
$pdo = new PDO($dsn, $username, $password);

// Ambil data dari form website
$tanggal = $_POST['tanggal'];
$jenis_pendaftaran = $_POST['jenis_pendaftaran'];
$tanggal_masuk_sekolah = $_POST['tanggal_masuk_sekolah'];
$nis = $_POST['nis'];
$nomor_peserta_ujian = $_POST['nomor_peserta_ujian'];
$pernah_paud = $_POST['pernah_paud'];
$pernah_tk = $_POST['pernah_tk'];
$no_seri_skhun_sebelumnya = $_POST['no_seri_skhun_sebelumnya'];
$no_seri_ijasah_sebelumnya = $_POST['no_seri_ijasah_sebelumnya'];
$hobi = $_POST['hobi'];
$cita_cita = $_POST['cita_cita'];
$nama_lengkap = $_POST['nama_lengkap'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$nisn = $_POST['nisn'];
$nik = $_POST['nik'];
$tempat_lahir = $_POST['tempat_lahir'];
$tanggal_lahir = $_POST['tanggal_lahir'];
$agama = $_POST['agama'];
$berkebutuhan_khusus = $_POST['berkebutuhan_khusus'];
$alamat_jalan = $_POST['alamat_jalan'];
$rt = $_POST['rt'];
$rw = $_POST['rw'];
$nama_dusun = $_POST['nama_dusun'];
$nama_kelurahan_desa = $_POST['nama_kelurahan_desa'];
$kecamatan = $_POST['kecamatan'];
$kode_pos = $_POST['kode_pos'];
$tempat_tinggal = $_POST['tempat_tinggal'];
$moda_transportasi = $_POST['moda_transportasi'];
$nomor_hp = $_POST['nomor_hp'];
$nomor_telepon = $_POST['nomor_telepon'];
$email_pribadi = $_POST['email_pribadi'];
$penerima_kps_pkh_kip = $_POST['penerima_kps_pkh_kip'];
$no_kps_pkh_kip = $_POST['no_kps_pkh_kip'];
$kewarganegaraan = $_POST['kewarganegaraan'];
$negara = $_POST['negara'];

$sql = "INSERT INTO form (
    tanggal, jenis_pendaftaran, tanggal_masuk_sekolah, nis, nomor_peserta_ujian, pernah_paud, pernah_tk,
    no_seri_skhun_sebelumnya, no_seri_ijasah_sebelumnya, hobi, cita_cita, jenis_kelamin, nisn, nik,
    tempat_lahir, tanggal_lahir, agama, berkebutuhan_khusus, alamat_jalan, rt, rw, nama_dusun,
    nama_kelurahan_desa, kecamatan, kode_pos, tempat_tinggal, moda_transportasi, nomor_hp, nomor_telepon,
    email_pribadi, penerima_kps_pkh_kip, no_kps_pkh_kip, kewarganegaraan, negara
) 
VALUES (
    :tanggal, :jenis_pendaftaran, :tanggal_masuk_sekolah, :nis, :nomor_peserta_ujian, :pernah_paud, :pernah_tk,
    :no_seri_skhun_sebelumnya, :no_seri_ijasah_sebelumnya, :hobi, :cita_cita, :jenis_kelamin, :nisn, :nik,
    :tempat_lahir, :tanggal_lahir, :agama, :berkebutuhan_khusus, :alamat_jalan, :rt, :rw, :nama_dusun,
    :nama_kelurahan_desa, :kecamatan, :kode_pos, :tempat_tinggal, :moda_transportasi, :nomor_hp, :nomor_telepon,
    :email_pribadi, :penerima_kps_pkh_kip, :no_kps_pkh_kip, :kewarganegaraan, :negara
)";

// Buat prepared statement untuk menjalankan query
$stmt = $pdo->prepare($sql);

// Bind parameter ke prepared statement
$stmt->bindParam(':tanggal', $tanggal);
$stmt->bindParam(':jenis_pendaftaran', $jenis_pendaftaran);
$stmt->bindParam(':tanggal_masuk_sekolah', $tanggal_masuk_sekolah);
$stmt->bindParam(':nis', $nis);
$stmt->bindParam(':nomor_peserta_ujian', $nomor_peserta_ujian);
$stmt->bindParam(':pernah_paud', $pernah_paud);
$stmt->bindParam(':pernah_tk', $pernah_tk);
$stmt->bindParam(':no_seri_skhun_sebelumnya', $no_seri_skhun_sebelumnya);
$stmt->bindParam(':no_seri_ijasah_sebelumnya', $no_seri_ijasah_sebelumnya);
$stmt->bindParam(':hobi', $hobi);
$stmt->bindParam(':cita_cita', $cita_cita);
$stmt->bindParam(':jenis_kelamin', $jenis_kelamin);
$stmt->bindParam(':nisn', $nisn);
$stmt->bindParam(':nik', $nik);
$stmt->bindParam(':tempat_lahir', $tempat_lahir);
$stmt->bindParam(':tanggal_lahir', $tanggal_lahir);
$stmt->bindParam(':agama', $agama);
$stmt->bindParam(':berkebutuhan_khusus', $berkebutuhan_khusus);
$stmt->bindParam(':alamat_jalan', $alamat_jalan);
$stmt->bindParam(':rt', $rt);
$stmt->bindParam(':rw', $rw);
$stmt->bindParam(':nama_dusun', $nama_dusun);
$stmt->bindParam(':nama_kelurahan_desa', $nama_kelurahan_desa);
$stmt->bindParam(':kecamatan', $kecamatan);
$stmt->bindParam(':kode_pos', $kode_pos);
$stmt->bindParam(':tempat_tinggal', $tempat_tinggal);
$stmt->bindParam(':moda_transportasi', $moda_transportasi);
$stmt->bindParam(':nomor_hp', $nomor_hp);
$stmt->bindParam(':nomor_telepon', $nomor_telepon);
$stmt->bindParam(':email_pribadi', $email_pribadi);
$stmt->bindParam(':penerima_kps_pkh_kip', $penerima_kps_pkh_kip);
$stmt->bindParam(':no_kps_pkh_kip', $no_kps_pkh_kip);
$stmt->bindParam(':kewarganegaraan', $kewarganegaraan);
$stmt->bindParam(':negara', $negara);

// Eksekusi prepared statement
if ($stmt->execute()) {
// Jika query berhasil dijalankan
echo "Data siswa berhasil disimpan.";
} else {
// Jika query gagal dijalankan
echo "Terjadi kesalahan saat menyimpan data siswa.";
}

// Tutup koneksi database
unset($pdo);

?>

